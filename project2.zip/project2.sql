/*****************
name:Ahmad hasone
project 2
***************/




---**ex1
WITH YearlyIncome AS (
    SELECT 
        YEAR(i.InvoiceDate) AS Year,
        SUM(il.ExtendedPrice - il.TaxAmount) AS IncomePerYear,
        COUNT(DISTINCT MONTH(i.InvoiceDate)) AS NumberOfDistinctMonths
    FROM Sales.Invoices i
    JOIN Sales.InvoiceLines il ON i.InvoiceID = il.InvoiceID
    GROUP BY YEAR(i.InvoiceDate)
),
WithGrowth AS (
    SELECT 
        Year,
        IncomePerYear,
        NumberOfDistinctMonths,
        LAG(IncomePerYear) OVER (ORDER BY Year) AS YearlyLinearIncome
    FROM YearlyIncome
)
SELECT 
    Year,
    IncomePerYear,
    NumberOfDistinctMonths,
    YearlyLinearIncome,
       CASE 
		 WHEN YearlyLinearIncome IS NULL OR YearlyLinearIncome = 0 THEN NULL
		 ELSE ROUND(100.0 * (IncomePerYear - YearlyLinearIncome) / YearlyLinearIncome, 2)
	END AS GrowthRate

FROM WithGrowth;



---***ex2
WITH QuarterlyIncome AS (
    SELECT
        YEAR(i.InvoiceDate) AS TheYear,
        DATEPART(QUARTER, i.InvoiceDate) AS TheQuarter,
        c.CustomerName,
        SUM(il.ExtendedPrice - il.TaxAmount) AS IncomePerYear,
        ROW_NUMBER() OVER (
            PARTITION BY YEAR(i.InvoiceDate), DATEPART(QUARTER, i.InvoiceDate)
            ORDER BY SUM(il.ExtendedPrice - il.TaxAmount) DESC
        ) AS DNR
    FROM Sales.Invoices i
    JOIN Sales.InvoiceLines il ON i.InvoiceID = il.InvoiceID
    JOIN Sales.Customers c ON i.CustomerID = c.CustomerID
    GROUP BY
        YEAR(i.InvoiceDate),
        DATEPART(QUARTER, i.InvoiceDate),
        c.CustomerName
)
SELECT *
FROM QuarterlyIncome
WHERE DNR <= 5
ORDER BY TheYear, TheQuarter, DNR;


---***ex3
SELECT
    si.StockItemID,
    si.StockItemName,
    SUM(il.ExtendedPrice - il.TaxAmount) AS TotalProfit
FROM Sales.InvoiceLines il
JOIN Warehouse.StockItems si ON il.StockItemID = si.StockItemID
GROUP BY si.StockItemID, si.StockItemName
ORDER BY TotalProfit DESC
OFFSET 0 ROWS FETCH NEXT 10 ROWS ONLY;


---***ex4
SELECT 
    ROW_NUMBER() OVER (ORDER BY (s.RecommendedRetailPrice - s.UnitPrice) DESC) AS Rn,
    s.StockItemID,
    s.StockItemName,
    s.UnitPrice,
    s.RecommendedRetailPrice,
    (s.RecommendedRetailPrice - s.UnitPrice) AS NominalProductProfit,
    DENSE_RANK() OVER (ORDER BY (s.RecommendedRetailPrice - s.UnitPrice) DESC) AS DNR
FROM Warehouse.StockItems s
WHERE s.UnitPrice IS NOT NULL AND s.RecommendedRetailPrice IS NOT NULL
ORDER BY NominalProductProfit DESC;

----***ex5
SELECT
    CAST(s.SupplierID AS VARCHAR) + ' - ' + s.SupplierName AS SupplierDetails,
    STRING_AGG(
        CAST(si.StockItemID AS VARCHAR) + ' ' + si.StockItemName, 
        ' / '
    ) AS ProductDetails
FROM Warehouse.StockItems si
JOIN Purchasing.Suppliers s ON si.SupplierID = s.SupplierID
GROUP BY s.SupplierID, s.SupplierName
ORDER BY s.SupplierID;


----***ex6
SELECT TOP 5
    c.CustomerID,
    city.CityName,
    country.CountryName,
    country.Continent,
    country.Region,
    SUM(il.ExtendedPrice) AS TotalExtendedPrice
FROM Sales.InvoiceLines il
JOIN Sales.Invoices i ON il.InvoiceID = i.InvoiceID
JOIN Sales.Customers c ON i.CustomerID = c.CustomerID
JOIN Application.Cities city ON c.DeliveryCityID = city.CityID
JOIN Application.StateProvinces sp ON city.StateProvinceID = sp.StateProvinceID
JOIN Application.Countries country ON sp.CountryID = country.CountryID
GROUP BY
    c.CustomerID,
    city.CityName,
    country.CountryName,
    country.Continent,
    country.Region
ORDER BY TotalExtendedPrice DESC;


----***ex7
WITH MonthlyTotals AS (
    SELECT
        YEAR(o.OrderDate) AS OrderYear,
        MONTH(o.OrderDate) AS OrderMonth,
        SUM(ol.UnitPrice * ol.Quantity) AS MonthlyTotal
    FROM Sales.Orders o
    JOIN Sales.OrderLines ol ON o.OrderID = ol.OrderID
    GROUP BY YEAR(o.OrderDate), MONTH(o.OrderDate)
),
CumulativeTotals AS (
    SELECT 
        OrderYear,
        OrderMonth,
        MonthlyTotal,
        SUM(MonthlyTotal) OVER (
            PARTITION BY OrderYear 
            ORDER BY OrderMonth
        ) AS CumulativeTotal
    FROM MonthlyTotals
),
YearlyTotals AS (
    SELECT
        OrderYear,
        NULL AS OrderMonth,
        SUM(MonthlyTotal) AS MonthlyTotal,
        SUM(MonthlyTotal) AS CumulativeTotal
    FROM MonthlyTotals
    GROUP BY OrderYear
)
SELECT 
    OrderYear,
    ISNULL(CAST(OrderMonth AS VARCHAR), 'Grand Total') AS OrderMonth,
    MonthlyTotal,
    CumulativeTotal
FROM (
    SELECT * FROM CumulativeTotals
    UNION ALL
    SELECT * FROM YearlyTotals
) AS Combined
ORDER BY OrderYear, 
         CASE WHEN OrderMonth IS NULL THEN 13 ELSE OrderMonth END;




--***ex8
SELECT 
    OrderMonth,
    ISNULL([2013], 0) AS [2013],
    ISNULL([2014], 0) AS [2014],
    ISNULL([2015], 0) AS [2015],
    ISNULL([2016], 0) AS [2016]
FROM (
    SELECT 
        MONTH(OrderDate) AS OrderMonth,
        YEAR(OrderDate) AS OrderYear,
        OrderID
    FROM Sales.Orders
) AS SourceData
PIVOT (
    COUNT(OrderID)
    FOR OrderYear IN ([2013], [2014], [2015], [2016])
) AS PivotTable
ORDER BY OrderMonth;

---***ex9
WITH OrdersWithLag AS (
    SELECT 
        o.CustomerID,
        c.CustomerName,
        o.OrderDate,
        LAG(o.OrderDate) OVER (PARTITION BY o.CustomerID ORDER BY o.OrderDate) AS PreviousOrderDate
    FROM Sales.Orders o
    JOIN Sales.Customers c ON o.CustomerID = c.CustomerID
),
OrdersWithDiff AS (
    SELECT *,
           DATEDIFF(DAY, PreviousOrderDate, OrderDate) AS DaysSinceLastOrder
    FROM OrdersWithLag
),
AvgDays AS (
    SELECT 
        CustomerID,
        AVG(DATEDIFF(DAY, PreviousOrderDate, OrderDate) ) AS AvgDaysBetweenOrders
    FROM OrdersWithLag
    WHERE PreviousOrderDate IS NOT NULL
    GROUP BY CustomerID
)
SELECT 
    o.CustomerID,
    o.CustomerName,
    o.OrderDate,
    o.PreviousOrderDate,
    o.DaysSinceLastOrder,
    ROUND(a.AvgDaysBetweenOrders, 0) AS AvgDaysBetweenOrders,
    CASE 
        WHEN o.DaysSinceLastOrder IS NULL THEN 'First Order'
        WHEN o.DaysSinceLastOrder > 2 * a.AvgDaysBetweenOrders THEN 'Potential Churn'
        ELSE 'Active'
    END AS CustomerStatus
FROM OrdersWithDiff o
LEFT JOIN AvgDays a ON o.CustomerID = a.CustomerID
ORDER BY o.CustomerID, o.OrderDate;


---***ex10
WITH CleanedCustomers AS (
    SELECT
        cc.CustomerCategoryName,
        LEFT(sc.CustomerName,
            IIF(CHARINDEX('(', sc.CustomerName) = 0,
                LEN(sc.CustomerName),
                CHARINDEX('(', sc.CustomerName) - 2)
        ) AS CleanCustomerName
    FROM Sales.Customers sc
    JOIN Sales.CustomerCategories cc
        ON sc.CustomerCategoryID = cc.CustomerCategoryID
),
CategoryDistribution AS (
    SELECT
        CustomerCategoryName,
        COUNT(DISTINCT CleanCustomerName) AS CustomerCOUNT,
        (SELECT COUNT(DISTINCT LEFT(CustomerName,
                                    IIF(CHARINDEX('(', CustomerName) = 0,
                                        LEN(CustomerName),
                                        CHARINDEX('(', CustomerName) - 2)))
         FROM Sales.Customers) AS TotalCustCount
    FROM CleanedCustomers
    GROUP BY CustomerCategoryName
)
SELECT
    CustomerCategoryName,
    CustomerCOUNT,
    TotalCustCount,
    FORMAT(100.0 * CustomerCOUNT / TotalCustCount, 'N2') + '%' AS DistributionFactor
FROM CategoryDistribution
ORDER BY CustomerCategoryName;

